import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

base_dir = Path('data/data/xhs/csv')

# Load CSV with robust encoding
def load_csv(path: Path):
    for enc in ['utf-8-sig', 'utf-8', 'gbk', 'ansi']:
        try:
            return pd.read_csv(path, encoding=enc)
        except Exception:
            continue
    raise ValueError(f'无法读取文件: {path}')

# 统一时间列到 pandas datetime 的工具函数
def normalize_time_series(s: pd.Series, prefer_ms=True) -> pd.Series:
    if s is None:
        return s
    # 已是 datetime 直接返回
    if 'datetime64' in str(s.dtype):
        return s
    # 数值：按毫秒解析
    if pd.api.types.is_numeric_dtype(s):
        return pd.to_datetime(s, unit='ms', errors='coerce')
    # 对象：分别处理纯数字与日期字符串
    s_str = s.astype(str)
    # 纯数字（可能是毫秒/秒）
    mask_digits = s_str.str.fullmatch(r"\d+")
    out = pd.to_datetime(s_str.where(~mask_digits), errors='coerce')
    # 对纯数字部分按毫秒或秒解析（优先毫秒）
    if mask_digits.any():
        nums = s_str.where(mask_digits)
        # 长度>=12 基本判断为毫秒
        ms_mask = nums.str.len() >= 12 if prefer_ms else nums.str.len() > 10
        parsed_ms = pd.to_datetime(nums.where(ms_mask), unit='ms', errors='coerce')
        parsed_s = pd.to_datetime(nums.where(~ms_mask), unit='s', errors='coerce')
        out = out.combine_first(parsed_ms).combine_first(parsed_s)
    return out

# Load four files
file1 = base_dir / 'search_contents_2025-12-04.csv'
file2 = base_dir / 'detail_contents_2025-12-08.csv'
file3 = base_dir / 'detail_contents_2025-12-04.csv'
file4 = Path('data/data/douyin/csv/search_contents_2025-12-04_converted.csv')

df1 = load_csv(file1)
df2 = load_csv(file2)
df3 = load_csv(file3)
df4 = load_csv(file4)

print(f'文件1行数: {len(df1)}')
print(f'文件2行数: {len(df2)}')
print(f'文件3行数: {len(df3)}')
print(f'文件4行数: {len(df4)}')

# 先处理各文件时间列
if 'time' in df1.columns:
    df1.loc[:, 'time'] = normalize_time_series(df1['time'])
if 'time' in df2.columns:
    df2.loc[:, 'time'] = normalize_time_series(df2['time'])
if 'time' in df3.columns:
    df3.loc[:, 'time'] = normalize_time_series(df3['time'])
if 'create_time' in df4.columns:
    df4.loc[:, 'create_time'] = normalize_time_series(df4['create_time'])
    print('抖音数据时间已转换')

# Standardize column names for file4 (douyin)
# Map douyin columns to xhs columns
df4_rename = {
    'aweme_id': 'note_id',
    'aweme_type': 'type',
    'create_time': 'time'
}
df4 = df4.rename(columns=df4_rename)

# Select common columns for all files
common_columns = ['note_id', 'type', 'title', 'desc', 'user_id', 'nickname', 
                   'avatar', 'liked_count', 'collected_count', 'comment_count', 
                   'share_count', 'ip_location', 'time']

# Keep only common columns if they exist
df1_filtered = df1[[col for col in common_columns if col in df1.columns]]
df2_filtered = df2[[col for col in common_columns if col in df2.columns]]
df3_filtered = df3[[col for col in common_columns if col in df3.columns]]
df4_filtered = df4[[col for col in common_columns if col in df4.columns]]

# Merge all four
merged_df = pd.concat([df1_filtered, df2_filtered, df3_filtered, df4_filtered], ignore_index=True)
print(f'合并后行数: {len(merged_df)}')

# Deduplicate by complete row
final_df = merged_df.drop_duplicates(keep='first')
print(f'去重后行数: {len(final_df)}')
print(f'去除重复: {len(merged_df) - len(final_df)} 条')

# 再次兜底规范时间列（合并后可能为 object）
final_df.loc[:, 'time'] = normalize_time_series(final_df['time'])

print(f'\ntime列前5行:')
print(final_df['time'].head())

# 打印各来源时间范围帮助排查
def safe_range(df, col):
    if col in df.columns:
        return f"{pd.to_datetime(df[col], errors='coerce').min()} ~ {pd.to_datetime(df[col], errors='coerce').max()}"
    return 'N/A'

print('\n各来源时间范围:')
print('文件1:', safe_range(df1, 'time'))
print('文件2:', safe_range(df2, 'time'))
print('文件3:', safe_range(df3, 'time'))
print('文件4:', safe_range(df4, 'time'))

# Add note_seq column to the left of note_id
final_df.insert(0, 'note_seq', range(1, len(final_df) + 1))

# Save to merged_results and legacy path
merged_dir = Path('merged_results')
merged_dir.mkdir(parents=True, exist_ok=True)
output_path_merged = merged_dir / 'final_contents.csv'
final_df.to_csv(output_path_merged, index=False, encoding='utf-8-sig')

# 同步保存一份到原目录以兼容其他脚本
legacy_path = base_dir / 'final_contents.csv'
final_df.to_csv(legacy_path, index=False, encoding='utf-8-sig')

# 写入时间范围摘要
summary_path = merged_dir / 'posts_time_range.txt'
min_time = final_df['time'].min()
max_time = final_df['time'].max()
with open(summary_path, 'w', encoding='utf-8') as f:
    f.write('帖子时间范围\n')
    f.write(f'最早: {min_time}\n')
    f.write(f'最晚: {max_time}\n')
    f.write(f'总条数: {len(final_df)}\n')

print(f'\n最终文件已保存: {output_path_merged}')
print(f'时间范围: {min_time} ~ {max_time}')
print(f'总数据条数: {len(final_df)}')
