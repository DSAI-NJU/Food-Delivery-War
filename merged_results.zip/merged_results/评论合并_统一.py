import pandas as pd
from pathlib import Path

base_dir = Path('data/data/xhs/csv')

# Load CSV with robust encoding
def load_csv(path: Path):
    for enc in ['utf-8-sig', 'utf-8', 'gbk', 'ansi']:
        try:
            return pd.read_csv(path, encoding=enc)
        except Exception:
            continue
    raise ValueError(f'无法读取文件: {path}')

# Robust time normalization helper
def normalize_time_series(s: pd.Series, prefer_ms: bool = True) -> pd.Series:
    if s is None:
        return s
    if 'datetime64' in str(s.dtype):
        return s
    if pd.api.types.is_numeric_dtype(s):
        return pd.to_datetime(s, unit='ms', errors='coerce')
    s_str = s.astype(str)
    mask_digits = s_str.str.fullmatch(r"\d+")
    out = pd.to_datetime(s_str.where(~mask_digits), errors='coerce')
    if mask_digits.any():
        nums = s_str.where(mask_digits)
        ms_mask = nums.str.len() >= 12 if prefer_ms else nums.str.len() > 10
        parsed_ms = pd.to_datetime(nums.where(ms_mask), unit='ms', errors='coerce')
        parsed_s = pd.to_datetime(nums.where(~ms_mask), unit='s', errors='coerce')
        out = out.combine_first(parsed_ms).combine_first(parsed_s)
    return out

# Load three comment files
file1 = base_dir / 'detail_comments_2025-12-04_backup.csv'
file2 = base_dir / 'detail_comments_2025-12-08.csv'
file3 = Path('data/data/douyin/csv/search_comments_2025-12-04_converted.csv')

df1 = load_csv(file1)
df2 = load_csv(file2)
df3 = load_csv(file3)

print(f'文件1(小红书备份)行数: {len(df1)}')
print(f'文件2(小红书新)行数: {len(df2)}')
print(f'文件3(抖音)行数: {len(df3)}')

# Standardize column names for file3 (douyin)
# Map douyin columns to xhs columns
df3_rename = {
    'aweme_id': 'note_id'
}
df3 = df3.rename(columns=df3_rename)

# Convert time columns to consistent format before merging
if 'create_time' in df1.columns:
    df1.loc[:, 'create_time'] = normalize_time_series(df1['create_time'])
if 'create_time' in df2.columns:
    df2.loc[:, 'create_time'] = normalize_time_series(df2['create_time'])
if 'create_time' in df3.columns:
    df3.loc[:, 'create_time'] = normalize_time_series(df3['create_time'])

# Select common columns for all files
common_columns = ['comment_id', 'create_time', 'ip_location', 'note_id', 'content', 
                   'user_id', 'nickname', 'avatar', 'sub_comment_count', 'like_count', 
                   'last_modify_ts', 'parent_comment_id']

# Keep only common columns if they exist
df1_filtered = df1[[col for col in common_columns if col in df1.columns]]
df2_filtered = df2[[col for col in common_columns if col in df2.columns]]
df3_filtered = df3[[col for col in common_columns if col in df3.columns]]

# Merge all three
merged_df = pd.concat([df1_filtered, df2_filtered, df3_filtered], ignore_index=True)
print(f'合并后行数: {len(merged_df)}')

# Deduplicate by complete row
final_df = merged_df.drop_duplicates(keep='first')
print(f'去重后行数: {len(final_df)}')
print(f'去除重复: {len(merged_df) - len(final_df)} 条')

print(f'\ncreate_time列前5行:')
print(final_df['create_time'].head())

# Move note_id and comment_id to front
cols = final_df.columns.tolist()
if 'comment_id' in cols:
    cols.remove('comment_id')
if 'note_id' in cols:
    cols.remove('note_id')
cols = ['note_id', 'comment_id'] + cols
final_df = final_df[cols]

# Save to final_comments_merged.csv
merged_dir = Path('merged_results')
merged_dir.mkdir(parents=True, exist_ok=True)
output_path = merged_dir / 'final_comments_merged.csv'
final_df.to_csv(output_path, index=False, encoding='utf-8-sig')
print(f'\n最终文件已保存: {output_path}')
print(f'总评论数: {len(final_df)}')

# Write time range summary
min_time = final_df['create_time'].min() if 'create_time' in final_df.columns else None
max_time = final_df['create_time'].max() if 'create_time' in final_df.columns else None
print(f"评论时间范围: {min_time} ~ {max_time}")
summary_path = merged_dir / 'comments_time_range.txt'
with open(summary_path, 'w', encoding='utf-8') as f:
    f.write('评论时间范围\n')
    f.write(f'最早: {min_time}\n')
    f.write(f'最晚: {max_time}\n')
    f.write(f'总评论数: {len(final_df)}\n')

print(f'\n前3行预览:')
print(final_df[['note_id', 'comment_id', 'create_time', 'content']].head(3))
